/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.awt.Image;
import javax.swing.ImageIcon;

/**
 *
 * @author shreya
 */
public class CarData {
    
    private String Brand;
    private String Model;
    private String Color;
    private String Year;
    private String Enginnumber;
    private String Number_of_seats;
    private String Licence_plates;
    private String Owner_name;
    private String Owner_number;
    private String Owner_email;
    private String Owner_ssn;
    private String Owner_address;
    private String Owner_DL;
    private String Warranty_year;
    private Image Photo;
    
    //Service Records
    private String Date;
    private String TypeofService;
    private String Amount;

    public String getDate() {
        return Date;
    }

    public void setDate(String Date) {
        this.Date = Date;
    }

    public String getTypeofService() {
        return TypeofService;
    }

    public void setTypeofService(String TypeofService) {
        this.TypeofService = TypeofService;
    }

    public String getAmount() {
        return Amount;
    }

    public void setAmount(String Amount) {
        this.Amount = Amount;
    }
    
    

    public String getBrand() {
        return Brand;
    }

    public void setBrand(String Brand) {
        this.Brand = Brand;
    }

    public String getModel() {
        return Model;
    }

    public void setModel(String Model) {
        this.Model = Model;
    }

    public String getColor() {
        return Color;
    }

    public void setColor(String Color) {
        this.Color = Color;
    }

    public String getYear() {
        return Year;
    }

    public void setYear(String Year) {
        this.Year = Year;
    }

    public String getEnginnumber() {
        return Enginnumber;
    }

    public void setEnginnumber(String Enginnumber) {
        this.Enginnumber = Enginnumber;
    }

    
    public String getNumber_of_seats() {
        return Number_of_seats;
    }

    public void setNumber_of_seats(String Number_of_seats) {
        this.Number_of_seats = Number_of_seats;
    }

    public String getLicence_plates() {
        return Licence_plates;
    }

    public void setLicence_plates(String Licence_plates) {
        this.Licence_plates = Licence_plates;
    }

    public String getOwner_name() {
        return Owner_name;
    }

    public void setOwner_name(String Owner_name) {
        this.Owner_name = Owner_name;
    }

    public String getOwner_number() {
        return Owner_number;
    }

    public void setOwner_number(String Owner_number) {
        this.Owner_number = Owner_number;
    }

    public String getOwner_email() {
        return Owner_email;
    }

    public void setOwner_email(String Owner_email) {
        this.Owner_email = Owner_email;
    }

    public String getOwner_ssn() {
        return Owner_ssn;
    }

    public void setOwner_ssn(String Owner_ssn) {
        this.Owner_ssn = Owner_ssn;
    }

    public String getOwner_address() {
        return Owner_address;
    }

    public void setOwner_address(String Owner_address) {
        this.Owner_address = Owner_address;
    }

//    public String getService_records() {
//        return Service_records;
//    }
//
//    public void setService_records(String Service_records) {
//        this.Service_records = Service_records;
//    }
    
    public String getOwner_DL(){
        return Owner_DL;
    }
    
    public void setOwner_DL(String Owner_DL){
        this.Owner_DL = Owner_DL;
    }

    public String getWarranty_year() {
        return Warranty_year;
    }

    public void setWarranty_year(String Warranty_year) {
        this.Warranty_year = Warranty_year;
    }

    public Image getPhoto() {
        return Photo;
    }

    public void setPhoto(Image Photo) {
        this.Photo = Photo;
    }
    
    
}
